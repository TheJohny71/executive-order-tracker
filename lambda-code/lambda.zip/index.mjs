export const handler = async (event) => {
    try {
        console.log('Event:', JSON.stringify(event));
        
        const path = event.path;
        const headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        };
        
        switch (path) {
            case '/':
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: 'Executive Orders API is working!',
                        time: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
                    })
                };
                
            case '/orders':
                // TODO: Replace with actual database call
                const mockOrders = [
                    {
                        id: 1,
                        title: "Sample Executive Order 1",
                        date: "2024-02-12"
                    },
                    {
                        id: 2,
                        title: "Sample Executive Order 2",
                        date: "2024-02-11"
                    }
                ];
                
                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        orders: mockOrders
                    })
                };
                
            default:
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        message: 'Route not found'
                    })
                };
        }
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                message: 'Internal server error',
                error: error.message
            })
        };
    }
};